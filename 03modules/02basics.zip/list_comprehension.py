nums = [2,3,4,5]

# creating a new list having double of current element
# double_num = [num*2 for num in nums]
# print(double_num)

# eve = [num for num in nums if num % 2 == 0]
# print(eve)

# double = []
# for n in nums: 
#     double.append(n ** 2)


# eveOddList = ["even" if n % 2 == 0 else "odd" for n in nums ]
# print(eveOddList)


# List comprehension with strings
# vowels= "aeiou"
# word = "python"

# res = [w for w in word if w in vowels]
# print(res)